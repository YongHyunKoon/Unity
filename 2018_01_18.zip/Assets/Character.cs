﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Character : MonoBehaviour {

    [SerializeField] GameObject bulletprefab;
    [SerializeField] GameObject[] lifeObjects;
    [SerializeField] Text ScoreText;
    private float speed;
    private int lifeCount;
    private int score;
    float delay = 0.0f;
    [SerializeField] GameObject bulletPrefab;
    void Awake()
    {
        speed = 5.0f;
        lifeCount = 3;
        score = 0;
    }

    // Update is called once per frame
    void Update () {
		if (Input.GetKey(KeyCode.UpArrow))
        {
            if (transform.position.y<4.0f) transform.position += Vector3.up * speed * Time.deltaTime;
            else
            {
                transform.position = new Vector3(transform.position.x, 4.0f, 0.0f);
        
            }

        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            if (transform.position.y > -4.0f) transform.position += Vector3.down * speed * Time.deltaTime;
            else
                transform.position = new Vector3(transform.position.x, -4.0f, 0.0f);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            if (transform.position.x > -3.0f) transform.position += Vector3.left * speed * Time.deltaTime;
            else
            {
                transform.position = new Vector3(-3.0f,transform.position.y, 0.0f);
            }
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            if (transform.position.x < 3.0f) transform.position += Vector3.right * speed * Time.deltaTime;
            else
            {
                transform.position = new Vector3(3.0f, transform.position.y, 0.0f);
            }
        }

        if (Input.GetKey(KeyCode.Space))
        {
            delay += Time.deltaTime;
            if (delay > 0.5f) {
                GameObject clone = Instantiate(bulletPrefab);
                clone.transform.position = transform.position + new Vector3(0.0f, 0.8f, 0.0f);
                delay = 0.0f;
            }
            
        }

    }
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.name.Equals("Monster"))
        {
            Life_Odd();
            col.GetComponent<Monster>().Exit();
        }
        if (col.tag.Equals("Meteo"))
        {
            Life_Odd();
            col.GetComponent<Monster>().Exit();
        }
    }
    void Life_Odd()
    {
        if(lifeCount > 1)
        {
            lifeObjects[lifeCount-1].gameObject.SetActive(false);
            lifeCount--;

        }
        else
        {
            PlayerPrefs.SetInt("Score", score);
            SceneManager.LoadScene("GG_scene");
        }
    }
    public void Update_score(int _score)
    {
        score += _score;
        ScoreText.text = "Score : " + score;
    }
}
