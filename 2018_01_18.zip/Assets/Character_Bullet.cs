﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character_Bullet : MonoBehaviour {
    Rigidbody2D rigid;

	// Use this for initialization
	void Start () {
        rigid = GetComponent<Rigidbody2D>();
        rigid.velocity = new Vector2(0.0f, 5.0f);
     

	}
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.name.Equals("Monster"))
        {
            GameObject.Find("Character").GetComponent<Character>().Update_score(100);


            col.GetComponent<Monster>().Exit();
            Destroy(gameObject);
        }
    }
    // Update is called once per frame
    void Update () {
		
	}
}
