﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character_Bullet : MonoBehaviour {
    Rigidbody2D rigid;

	// Use this for initialization
	void Start () {
        rigid = GetComponent<Rigidbody2D>();
        rigid.velocity = new Vector2(0.0f, 5.0f);
     

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
