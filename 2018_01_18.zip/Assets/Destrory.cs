﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destrory : MonoBehaviour {

    // Use this for initialization
    private void OnTriggerEnter2D(Collider2D Bullet)
    {
        Destroy(Bullet.gameObject);
    }
}
