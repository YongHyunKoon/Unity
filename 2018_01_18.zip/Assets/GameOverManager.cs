﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class GameOverManager : MonoBehaviour {
    [SerializeField] Text scoreText;
	// Use this for initialization
    
	void Start () {

        int score = PlayerPrefs.GetInt("Score");
        scoreText.text = "Your Score : " + score;
		
	}

	public void Btn_Return()
    {
        SceneManager.LoadScene("Intro_scene");
    }
	// Update is called once per frame
	void Update () {
		
	}
}
