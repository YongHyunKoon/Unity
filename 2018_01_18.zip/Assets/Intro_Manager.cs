﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Intro_Manager : MonoBehaviour {


    public void Btn_start()
    {
        SceneManager.LoadScene("abc");
    }
	// Use this for initialization
	
}
