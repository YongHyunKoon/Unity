﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Meteorite : MonoBehaviour {

    [SerializeField] GameObject explosionPrefab;
    private float speed;

    public void Init(Vector3 _pos)
    {
        speed = 6.0f;
        transform.position = _pos;
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        if (transform.position.y < -5.0)
        {
            Destroy(gameObject);
        }

        transform.position += Vector3.down * speed * Time.deltaTime;

	}
    public void Exit()
    {
        GameObject clone = Instantiate(explosionPrefab);
        clone.transform.position = transform.position;
        Destroy(gameObject);
    }
}
