﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour {
    [SerializeField] GameObject explosionPrefab;
    private float speed;
	// Use this for initialization
	public void Init(Vector3 _pos)
    {
        transform.position = _pos;
        speed = 5.0f;
    }
    private void Update()
    {
        if(transform.position.y < -5.0)
        {
            Destroy(gameObject);
        }
        transform.position += Vector3.down * speed * Time.deltaTime;
    }
    public void Exit()
    {
        GameObject clone = Instantiate(explosionPrefab);
        clone.transform.position = transform.position;
        Destroy(gameObject);
    }
}
